var searchData=
[
  ['good_899',['good',['../structClients.html#a45dde398d2d928794de3886c74c435f6',1,'Clients']]]
];
