var searchData=
[
  ['willmessages_597',['willMessages',['../structwillMessages.html',1,'']]],
  ['ws_5fframe_598',['ws_frame',['../structws__frame.html',1,'']]]
];
