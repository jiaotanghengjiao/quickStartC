var searchData=
[
  ['good_65',['good',['../structClients.html#a45dde398d2d928794de3886c74c435f6',1,'Clients']]]
];
