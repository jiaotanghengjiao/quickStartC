var searchData=
[
  ['qentry_585',['qEntry',['../structqEntry.html',1,'']]]
];
